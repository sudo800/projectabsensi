<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="shortcut icon" href="https://rubygems.org/favicon.ico" type="image/x-icon">
    <link href="https://rubygems.org/stylesheets/static.css" rel='stylesheet' type='text/css'>
    <title>Page not found | RubyGems.org</title>
  </head>
  <body>
    <div class="wrapper">
      <div class="image__wrapper">
        <img class="error__illustration__bubble" alt="Gem missing from treasure chest" src="https://rubygems.org/images/cross.png">
        <img height="530" alt="404 error" src="https://rubygems.org/images/sea_floor.svg">
      </div>
      <div class="content">
        <h1>Page not found.</h1>
        <p>It will be mine. Oh yes. It will be mine.</p>
      </div>
    </div>
  </body>
</html>
