<div class="form-group row">
    <label for="bank_name" class="col-sm-3 col-form-label">Bank Name</label>
    <div class="col-sm-5">
        <input type="text" class="form-control" name="bank_name" id="bank_name" value="{{ old('bank_name') }}">
        @error('bank_name')
            <p style="color:red;"> {{ $message }}</p>
        @enderror
    </div>
</div>
<div class="form-group row">
    <label for="no_rekening" class="col-sm-3 col-form-label">No Rekening</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" name="no_rekening" id="no_rekening" value="{{ old('no_rekening') }}">
        @error('no_rekening')
            <p style="color:red;"> {{ $message }}</p>
        @enderror
    </div>
</div>
<div class="form-group row">
    <label for="bank_price" class="col-sm-3 col-form-label">Atas Nama</label>
    <div class="col-sm-3">
        <input type="text" class="form-control" name="alias" id="alias" value="{{ old('alias') }}">
    </div>
</div>
