@extends('layouts.app')
@section('title', 'Bank')
@section('content')


    <div class="card card-primary card-outline">
        <div class="card-header">
          <h3 class="card-title">
            <i class="fas fa-book"></i>
            Bank List
          </h3>
          <!-- card tools -->
          <div class="card-tools">
            <button type="button"
                    class="btn btn-primary btn-sm"
                    data-card-widget="collapse"
                    data-toggle="tooltip"
                    title="Minimaze">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body">

            <!-- Button trigger modal -->
            <div class="row">
                <div class="col-md-8">
                    {{-- menampilkan error validasi --}}
                    @if (count($errors) > 0)
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                    @endif
                </div>
                <div class="col-md-1 align-right">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
                        Add
                    </button>
                </div>
                <div class="col-md-3">
                    <form action="{{ url()->current() }}">
                        <div class="input-group input-group">
                            <input class="form-control form-control-navbar" type="search" name="keyword" placeholder="Search" aria-label="Search">
                            <div class="input-group-append">
                            <button class="btn btn-primary" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <hr>

			<div class="card-body table-responsive p-0" style="height:500px;">
                <table class="table table-head-fixed table-bordered text-nowrap table-striped">
					<thead>
						<tr>
                            <th>No</th>
                            <th>Bank Name</th>
                            <th>No Rekening</th>
                            <th>Atas Nama</th>
                            <th>Action</th>
						</tr>
					</thead>
					<tbody>
						@foreach($banks as $index => $bank)
							<tr>
                                <td>{{ $index + $banks->firstItem() }}</td>
                                <td>{{$bank->bank_name}}</td>
                                <td>{{$bank->no_rekening}}</td>
                                <td>{{$bank->alias}}</td>
								<td>
									<button class="btn btn-info" data-bank_name="{{$bank->bank_name}}" data-no_rekening="{{$bank->no_rekening}}" data-alias="{{$bank->alias}}" data-bank_id={{$bank->bank_id}} data-toggle="modal" data-target="#edit">Edit</button>
									/
									<button class="btn btn-danger" data-bank_id={{$bank->bank_id}} data-toggle="modal" data-target="#delete">Delete</button>
								</td>
							</tr>
						@endforeach
					</tbody>
                </table>
			</div>
        </div>

        <div class="card-footer clearfix float-right">
            {{ $banks->links('vendor.pagination.bootstrap-4') }}
        </div>
    </div>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Bank New </h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="{{route('bank.store')}}" method="post" enctype="multipart/form-data" class="form-horizontal">
                    {{csrf_field()}}
                <div class="modal-body">
                        @include('bank.form')
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Bank Edit </h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            {{-- {{route('bank.update','test')}} --}}
            <form action="{{route('bank.update','test')}}" method="post" enctype="multipart/form-data" class="form-horizontal">
                    {{method_field('patch')}}
                    {{csrf_field()}}
                <div class="modal-body">
                        <input type="hidden" name="bank_id" id="bank_id" value="">
                        @include('bank.form')
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
  </div>
</div>
<!-- Modal -->
<div class="modal modal-danger fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content bg-danger">
        <div class="modal-header">
          <h4 class="modal-title">Delete Confirm</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="{{route('bank.destroy','test')}}" method="post" enctype="multipart/form-data">
                {{method_field('delete')}}
                {{csrf_field()}}
            <div class="modal-body">
                    <p class="text-center">
                        Are you sure you want to delete this?
                    </p>
                    <input type="hidden" name="bank_id" id="bank_id" value="">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-dismiss="modal">No, Cancel</button>
                <button type="submit" class="btn btn-warning">Yes, Delete</button>
            </div>
        </form>
    </div>
  </div>
</div>


@endsection
