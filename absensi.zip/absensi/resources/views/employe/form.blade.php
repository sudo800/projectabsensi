@extends('layouts.app')
@section('title', 'Employe')
@section('content')
<div class="card card-primary card-outline">
    <div class="card-header">
      <h3 class="card-title">
        <i class="fas fa-book"></i>
        {{ $title ?? 'Employe Update' }}

      </h3>
        <div class="card-tools">
            <button type="button"
                    class="btn btn-primary btn-sm"
                    data-card-widget="collapse"
                    data-toggle="tooltip"
                    title="Minimaze">
            <i class="fas fa-minus"></i>
            </button>
        </div>
    </div>
    @if ($cekurl=='store')
        <form action="{{route('employe.store')}}" method="post" enctype="multipart/form-data">
    @else
        <form action="{{route('employe.update',$employes->employe_id)}}" method="post" enctype="multipart/form-data">
        @method('patch')
        <input type="hidden" class="form-control" name="employe_id" value="{{$employes->employe_id }}">
    @endif
        {{-- {{csrf_field()}} --}}
        @csrf
        <div class="card-body">

            <!-- Button trigger modal -->
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group row">
                        <label for="employe_nik" class="col-sm-3 col-form-label">Employe NIK</label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" name="employe_nik" id="employe_nik" placeholder="NIK" value="{{ old('employe_nik') ?? $employes->employe_nik }}">
                            @error('employe_nik')
                                <p style="color:red;"> {{ $message }}</p>
                            @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="employe_name" class="col-sm-3 col-form-label">Employe Name</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="employe_name" id="employe_name" placeholder="Name" value="{{ old('employe_name') ?? $employes->employe_name }}">
                            @error('employe_name')
                                <p style="color:red;"> {{ $message }}</p>
                            @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="employe_address" class="col-sm-3 col-form-label">Employe Address</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="employe_address" id="employe_address" placeholder="Address" value="{{ old('employe_address') ?? $employes->employe_address }}">
                            @error('employe_address')
                                <p style="color:red;"> {{ $message }}</p>
                            @enderror
                        </div>
                    </div>
                    <div class="input-group row">
                        <label for="file" class="col-sm-3 col-form-label">Employe Photo</label>
                        <div class="input-group-append col-sm-5">
                            <input type="file" name="file" class="form-control" placeholder="employe Photo" >
                            <div class="input-group-text">
                                <span class="fas fa-image"></span>
                            </div>
                        </div>
                        @error('file')
                            <div class="alert alert-danger">
                                <span>{{ $message }}</span>
                            </div>
                        @enderror
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group row">
                        <label for="employe_email" class="col-sm-3 col-form-label">Employe Email</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="employe_email" id="employe_email" placeholder="Email" value="{{ old('employe_email') ?? $employes->employe_email }}">
                            @error('employe_email')
                                <p style="color:red;"> {{ $message }}</p>
                            @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="employe_place_of_birthday" class="col-sm-3 col-form-label">TTL</label>
                        <div class="col-sm-5">
                            <input type="text" class="form-control" name="employe_place_of_birthday" id="employe_place_of_birthday" placeholder="Tempat Lahir" value="{{ old('employe_place_of_birthday') ?? $employes->employe_place_of_birthday }}">
                            @error('employe_place_of_birthday')
                                <p style="color:red;"> {{ $message }}</p>
                            @enderror
                        </div>
                        <div class="col-sm-4">
                            <div class="input-group date" id="employe_date_of_birthday" data-target-input="nearest">
                                @php
                                    // echo $tanggal;
                                    $tanggal = $tanggal ?? date('m-d-Y', strtotime($employes->employe_date_of_birthday));
                                @endphp
                                <input type="text" name="employe_date_of_birthday" id="employe_date_of_birthday1" placeholder="Tanggal Lahir" value="{{ old('employe_date_of_birthday') ?? $tanggal  }}" class="form-control datetimepicker-input" data-target="#employe_date_of_birthday"/>
                                <div class="input-group-append" data-target="#employe_date_of_birthday" data-toggle="datetimepicker">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>

                            </div>
                            @error('employe_date_of_birthday')
                            <p style="color:red;"> {{ $message }}</p>
                        @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="employe_gender" class="col-sm-3 col-form-label">Gender</label>
                        <div class="col-sm-7">
                            <select class="custom-select form-control" name="employe_gender" id="employe_gender" placeholder="Jenis Kelamin">
                                <option value="{{ old('employe_gender') ?? $employes->employe_gender }}">{{ old('employe_gender') ?? $employes->employe_gender }}</option>
                                <option value="Laki-Laki">Laki-Laki</option>
                                <option value="Wanita">Wanita</option>
                            </select>
                            @error('employe_gender')
                                <p style="color:red;"> {{ $message }}</p>
                            @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="position_id" class="col-sm-3 col-form-label">Position</label>
                        <div class="col-sm-7">
                            <select class="custom-select form-control" name="position_id" id="position_id" placeholder="Position">
                                <option></option>
                                @php
                                    $position_name = $position_name ?? $employes->position->position_name;
                                @endphp
                                <option value="{{ $employes->position_id }}" selected>{{ $position_name }}</option>
                                {{-- <option selected>ss</option> --}}
                                {{-- @foreach ($positions as $position)
                                    {{-- @if ($position->position_id==$employe->position_id)
                                        <option value="{{ $employe->position_id }}" selected>{{ $employe->position->position_name }}</option>
                                    @endif --}}
                                    {{-- <option value="{{ $position->position_id==$employe->position_id ? 'selected' : '' }}">{{ $position->position_name }}</option> --}}
                                {{-- @endforeach --}}

                                @foreach ($positions as $position)
                                    <option value="{{ $position->position_id }}">{{ $position->position_name }}</option>
                                @endforeach
                            </select>
                            @error('position_id')
                                <p style="color:red;"> {{ $message }}</p>
                            @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="office_id" class="col-sm-3 col-form-label">Work Placement</label>
                        <div class="col-sm-9">
                            {{-- <input type="text" class="form-control" disabled id="office_id1" value="{{ old('office_id') }}"> --}}
                            <div class="select2-purple">
                                {{-- <select class="select2" name="office_id[]"  id="office_id1" multiple="multiple" data-placeholder="Select a State" data-dropdown-css-class="select2-purple" style="width: 100%;"> --}}
                                <select class="select2" name="office_id[]"  multiple="multiple" data-placeholder="Office" style="width: 100%;">
                                    <option value="{{ old('office_id') }}">{{ old('office_name') }}</option>
                                    @foreach ($employes->offices as $office)
                                        <option value="{{ $office->office_id }}" selected>{{ $office->office_name }}</option>
                                    @endforeach
                                    @foreach ($offices as $office)
                                        <option value="{{ $office->office_id }}">{{ $office->office_name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            @error('office_id')
                                <p style="color:red;"> {{ $message }}</p>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="align-right">
                    <br>
                    <a href="{{ route('employe.index') }}" class="btn btn-warning">Back</a>
                    <button type="submit" class="btn btn-primary">{{ $submit ?? 'Update' }}</button>
                </div>
            </form>

        </div>


@endsection
