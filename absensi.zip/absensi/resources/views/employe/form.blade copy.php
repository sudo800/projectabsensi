
<div class="form-group row">
    <label for="employe_nik" class="col-sm-3 col-form-label">Employe NIK</label>
    <div class="col-sm-3">
        <input type="text" class="form-control" name="employe_nik" id="employe_nik" value="{{ old('employe_nik') }}">
        @error('employe_nik')
            <p style="color:red;"> {{ $message }}</p>
        @enderror
    </div>
</div>
<div class="form-group row">
    <label for="employe_name" class="col-sm-3 col-form-label">Employe Name</label>
    <div class="col-sm-5">
        <input type="text" class="form-control" name="employe_name" id="employe_name" value="{{ old('employe_name') }}">
        @error('employe_name')
            <p style="color:red;"> {{ $message }}</p>
        @enderror
    </div>
</div>
<div class="form-group row">
    <label for="employe_address" class="col-sm-3 col-form-label">Employe Address</label>
    <div class="col-sm-5">
        <input type="text" class="form-control" name="employe_address" id="employe_address" value="{{ old('employe_address') }}">
        @error('employe_address')
            <p style="color:red;"> {{ $message }}</p>
        @enderror
    </div>
</div>
<div class="input-group row">
    <label for="file" class="col-sm-3 col-form-label">Employe Photo</label>
    <div class="input-group-append col-sm-5">
        <input type="file" name="file" class="form-control" placeholder="employe Photo" >
        <div class="input-group-text">
            <span class="fas fa-image"></span>
        </div>
    </div>
    @error('file')
        <div class="alert alert-danger">
            <span>{{ $message }}</span>
        </div>
    @enderror
</div>
<br>
<div class="form-group row">
    <label for="employe_email" class="col-sm-3 col-form-label">Employe Email</label>
    <div class="col-sm-4">
        <input type="text" class="form-control" name="employe_email" id="employe_email" value="{{ old('employe_email') }}">
        @error('employe_email')
            <p style="color:red;"> {{ $message }}</p>
        @enderror
    </div>
</div>
<div class="form-group row">
    <label for="employe_place_of_birthday" class="col-sm-3 col-form-label">TTL</label>
    <div class="col-sm-4">
        <input type="text" class="form-control" name="employe_place_of_birthday" id="employe_place_of_birthday" value="{{ old('employe_place_of_birthday') }}">
        @error('employe_place_of_birthday')
            <p style="color:red;"> {{ $message }}</p>
        @enderror
    </div>
    <div class="col-sm-3">
        <div class="input-group date" id="employe_date_of_birthday" data-target-input="nearest">
            <input type="text" name="employe_date_of_birthday" id="employe_date_of_birthday1" class="form-control datetimepicker-input" data-target="#employe_date_of_birthday"/>
            <div class="input-group-append" data-target="#employe_date_of_birthday" data-toggle="datetimepicker">
                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
            </div>

        </div>
        @error('employe_date_of_birthday')
        <p style="color:red;"> {{ $message }}</p>
    @enderror
    </div>
</div>
<div class="form-group row">
    <label for="employe_gender" class="col-sm-3 col-form-label">Gender</label>
    <div class="col-sm-3">
        <select class="custom-select form-control" name="employe_gender" id="employe_gender">
            <option value="{{ old('employe_gender') }}">{{ old('employe_gender') }}</option>
            <option value="Laki-Laki">Laki-Laki</option>
            <option value="Wanita">Wanita</option>
          </select>
        @error('employe_gender')
            <p style="color:red;"> {{ $message }}</p>
        @enderror
    </div>
</div>
<div class="form-group row">
    <label for="position_id" class="col-sm-3 col-form-label">Position</label>
    <div class="col-sm-3">
        <select class="custom-select form-control" name="position_id" id="position_id">
            <option value="{{ old('position_id') }}">{{ old('position_name') }}</option>
            {{-- <option value="{{ $employe->position_id }}" selected>{{ $employe->position->position_name }}</option> --}}
            {{-- <option selected>ss</option> --}}
            {{-- @foreach ($positions as $position)
                {{-- @if ($position->position_id==$employe->position_id)
                    <option value="{{ $employe->position_id }}" selected>{{ $employe->position->position_name }}</option>
                @endif --}}
                {{-- <option value="{{ $position->position_id==$employe->position_id ? 'selected' : '' }}">{{ $position->position_name }}</option> --}}
            {{-- @endforeach --}}

            @foreach ($positions as $position)
                <option value="{{ $position->position_id }}">{{ $position->position_name }}</option>
            @endforeach
          </select>
        @error('position_id')
            <p style="color:red;"> {{ $message }}</p>
        @enderror
    </div>
</div>

<div class="form-group row">
    <label for="office_id" class="col-sm-3 col-form-label">Work Placement</label>
    <div class="col-sm-9">
        <input type="text" class="form-control" disabled id="office_id1" value="{{ old('office_id') }}">
        <div class="select2-purple">
            {{-- <select class="select2" name="office_id[]"  id="office_id1" multiple="multiple" data-placeholder="Select a State" data-dropdown-css-class="select2-purple" style="width: 100%;"> --}}
            <select class="select2" name="office_id[]"  multiple="multiple" data-placeholder="Office" style="width: 100%;">
                <option value="{{ old('office_id') }}">{{ old('office_name') }}</option>
                @foreach ($employe->offices as $office)
                    <option value="{{ $office->office_id }}" >{{ $office->office_name }}</option>
                @endforeach
                {{-- @foreach ($offices as $office)
                    <option value="{{ $office->office_id }}">{{ $office->office_name }}</option>
                @endforeach --}}
            </select>
          </div>
        @error('office_id')
            <p style="color:red;"> {{ $message }}</p>
        @enderror
    </div>
</div>
