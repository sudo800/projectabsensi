@extends('layouts.app')
@section('title', 'Employe')
@section('content')


    <div class="card card-primary card-outline">
        <div class="card-header">
          <h3 class="card-title">
            <i class="fas fa-book"></i>
            Employe List
          </h3>
          <!-- card tools -->
          <div class="card-tools">
            <button type="button"
                    class="btn btn-primary btn-sm"
                    data-card-widget="collapse"
                    data-toggle="tooltip"
                    title="Minimaze">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body">

            <!-- Button trigger modal -->
            <div class="row">
                <div class="col-md-8">
                    {{ $employes->links('vendor.pagination.bootstrap-4') }}
                    {{-- menampilkan error validasi --}}
                    @if (count($errors) > 0)
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                    @endif
                </div>
                <div class="col-md-1 align-right">
                    <a href="{{ route('employe.create') }}" class="btn btn-primary"> create</a>
                </div>
                <div class="col-md-3">
                    <form action="{{ url()->current() }}">
                        <div class="input-group input-group">
                            <input class="form-control form-control-navbar" type="search" name="keyword" placeholder="Search" aria-label="Search">
                            <div class="input-group-append">
                            <button class="btn btn-primary" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <hr>

			<div class="card-body table-responsive p-0" style="height:800px;">
                <table class="table table-head-fixed table-bordered text-nowrap table-striped">
					<thead>
						<tr>
                            <th>No</th>
                            <th>NIK</th>
                            <th>Employe Name</th>
                            <th>Employe Photo</th>
                            <th>Employe Email</th>
                            <th>Address</th>
                            <th>Tempat Tanggal Lahir</th>
                            <th>Gender</th>
                            <th>Position</th>
                            <th>Work Place</th>
                            <th>Action</th>
						</tr>
					</thead>
					<tbody>
						@foreach($employes as $index => $employe)
							<tr>
                                <td>{{ $index + $employes->firstItem() }}</td>
                                <td>{{$employe->employe_nik}}</td>
                                <td>{{$employe->employe_name}}</td>
                                <td>
                                    <img src="{{ asset('/uploadgambar/employe/'.$employe->employe_photo) }}" class=" elevation-2" alt="Employee Foto" height="100pcx">
                                </td>
                                <td>{{$employe->employe_email}}</td>
                                <td>{{$employe->employe_address}}</td>
                                <td>{{$employe->employe_place_of_birthday.','.$employe->employe_date_of_birthday}}</td>
                                <td>{{$employe->employe_gender}}</td>

                                {{-- {{ dd($employe->position) }} --}}
                                 <td>{{$employe->position->position_name}} </td>
                                 <td> |
                                     {{-- {{ dd($employe->offices()) }} --}}
                                    @foreach ($employe->offices as $office)
                                        {{ $office->office_name.' | ' }}
                                    @endforeach
                                 </td>
								<td>
                                    <a href="{{ route('employe.edit',$employe->employe_id) }}" class="btn btn-info">Edit</a>/
									<button class="btn btn-danger" data-employe_id={{$employe->employe_id}} data-toggle="modal" data-target="#delete">Delete</button>
                                    {{-- <a href="{{route('employe/{'.$employe->employe_id.'}/edit')}}">cek</a> --}}
                                </td>
							</tr>
						@endforeach
					</tbody>
                </table>
			</div>
        </div>

        <div class="card-footer clearfix float-right">
            {{ $employes->links('vendor.pagination.bootstrap-4') }}
        </div>
    </div>

    {{-- Halaman : {{ $pegawai->currentPage() }} <br/>
	Jumlah Data : {{ $pegawai->total() }} <br/>
	Data Per Halaman : {{ $pegawai->perPage() }} <br/> --}}

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Employe New </h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="{{route('employe.store')}}" method="post" enctype="multipart/form-data" class="form-horizontal">
                    {{csrf_field()}}
                <div class="modal-body">
                        {{-- @include('employe.form') --}}
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Employe Edit </h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            {{-- {{route('employe.update','test')}} --}}
            <form action="{{route('employe.update','test')}}" method="post" enctype="multipart/form-data" class="form-horizontal">
                    {{method_field('patch')}}
                    {{csrf_field()}}
                <div class="modal-body">
                        <input type="hidden" name="employe_id" id="employe_id" value="">
                        {{-- @include('employe.form') --}}
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
  </div>
</div>
<!-- Modal -->
<div class="modal modal-danger fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content bg-danger">
        <div class="modal-header">
          <h4 class="modal-title">Delete Confirm</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="{{route('employe.destroy','test')}}" method="post" enctype="multipart/form-data">
                {{method_field('delete')}}
                {{csrf_field()}}
            <div class="modal-body">
                    <p class="text-center">
                        Are you sure you want to delete this?
                    </p>
                    <input type="hidden" name="employe_id" id="employe_id" value="">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-dismiss="modal">No, Cancel</button>
                <button type="submit" class="btn btn-warning">Yes, Delete</button>
            </div>
        </form>
    </div>
  </div>
</div>


@endsection
